import { NextResponse, type NextRequest } from "next/server";
import {
  isLocale,
  LOCALE_COOKIE,
  LOCALE_MAX_AGE,
} from "@/lib/i18n/config";
import { negotiateLocale } from "@/lib/i18n/negotiate";
import { decodeSession, SESSION_COOKIE } from "@/lib/auth/session-token";
import { canAccessPath, defaultHomeForRole } from "@/lib/auth/roles";

const PUBLIC_PATHS = ["/login"];

function isPublicPath(pathname: string) {
  if (PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(`${p}/`))) {
    return true;
  }
  // Static assets & API keep working; API routes can check session themselves if needed.
  if (pathname.startsWith("/api/")) return true;
  return false;
}

export function proxy(request: NextRequest): NextResponse {
  const { pathname } = request.nextUrl;
  const session = decodeSession(request.cookies.get(SESSION_COOKIE)?.value);

  if (!isPublicPath(pathname)) {
    if (!session) {
      const loginUrl = request.nextUrl.clone();
      loginUrl.pathname = "/login";
      loginUrl.searchParams.set("next", pathname);
      return NextResponse.redirect(loginUrl);
    }
    if (!canAccessPath(session.role, pathname)) {
      const homeUrl = request.nextUrl.clone();
      homeUrl.pathname = defaultHomeForRole(session.role);
      homeUrl.search = "";
      return NextResponse.redirect(homeUrl);
    }
  }

  if (pathname === "/login" && session) {
    const homeUrl = request.nextUrl.clone();
    homeUrl.pathname = defaultHomeForRole(session.role);
    homeUrl.search = "";
    return NextResponse.redirect(homeUrl);
  }

  const response = NextResponse.next();
  const cookieLocale = request.cookies.get(LOCALE_COOKIE)?.value;

  if (!isLocale(cookieLocale)) {
    response.cookies.set(
      LOCALE_COOKIE,
      negotiateLocale(request.headers.get("accept-language")),
      {
        maxAge: LOCALE_MAX_AGE,
        path: "/",
        sameSite: "lax",
        secure: process.env.NODE_ENV === "production",
      }
    );
  }

  return response;
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|sitemap.xml|robots.txt|.*\\.[^/]+$).*)",
  ],
};
