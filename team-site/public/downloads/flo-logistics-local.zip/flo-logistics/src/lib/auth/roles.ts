export const ROLES = ["ADMIN", "OPS_MANAGER", "DRIVER", "WAREHOUSE"] as const;

export type Role = (typeof ROLES)[number];

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  role: Role;
};

/** Path prefixes each role may access. Longer / more specific first in checks. */
const ROLE_PATHS: Record<Role, string[]> = {
  ADMIN: ["*"],
  OPS_MANAGER: [
    "/",
    "/dashboard",
    "/routing",
    "/vehicles",
    "/reports",
    "/methodology",
    "/ai/chat",
    "/system/gas-price",
  ],
  DRIVER: ["/", "/routing/plan", "/routing/dashboard", "/routing/methodology"],
  WAREHOUSE: [
    "/",
    "/routing/orders",
    "/computer-vision",
    "/routing/methodology",
  ],
};

export function isRole(value: unknown): value is Role {
  return typeof value === "string" && (ROLES as readonly string[]).includes(value);
}

export function canAccessPath(role: Role, pathname: string): boolean {
  const allowed = ROLE_PATHS[role];
  if (allowed.includes("*")) return true;

  const path = pathname.split("?")[0] || "/";

  return allowed.some((prefix) => {
    if (prefix === "/") return path === "/";
    return path === prefix || path.startsWith(`${prefix}/`);
  });
}

export function filterNavHrefs(role: Role, hrefs: string[]): string[] {
  return hrefs.filter((href) => canAccessPath(role, href));
}

export function defaultHomeForRole(role: Role): string {
  switch (role) {
    case "DRIVER":
      return "/routing/plan";
    case "WAREHOUSE":
      return "/computer-vision/load-detection";
    case "OPS_MANAGER":
      return "/routing/dashboard";
    default:
      return "/";
  }
}

export const DEMO_ACCOUNTS: Array<{
  email: string;
  password: string;
  name: string;
  role: Role;
  description: string;
}> = [
  {
    email: "admin@flo.demo",
    password: "demo1234",
    name: "Demo Admin",
    role: "ADMIN",
    description: "Full access — dashboards, admin, connectors, AI settings",
  },
  {
    email: "ops@flo.demo",
    password: "demo1234",
    name: "Ops Manager",
    role: "OPS_MANAGER",
    description: "Fleet, routing, reports, and AI assistant",
  },
  {
    email: "driver@flo.demo",
    password: "demo1234",
    name: "Bima Nugraha",
    role: "DRIVER",
    description: "Assigned routes and plan view",
  },
  {
    email: "warehouse@flo.demo",
    password: "demo1234",
    name: "Warehouse Lead",
    role: "WAREHOUSE",
    description: "Orders and computer-vision loading checks",
  },
];
