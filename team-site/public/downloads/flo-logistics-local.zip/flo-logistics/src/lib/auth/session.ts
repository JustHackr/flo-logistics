import { cookies } from "next/headers";
import type { SessionUser } from "@/lib/auth/roles";
import {
  decodeSession,
  SESSION_COOKIE,
} from "@/lib/auth/session-token";

export {
  encodeSession,
  decodeSession,
  sessionCookieOptions,
  SESSION_COOKIE,
  SESSION_MAX_AGE_SEC,
} from "@/lib/auth/session-token";

export async function getSession(): Promise<SessionUser | null> {
  const cookieStore = await cookies();
  return decodeSession(cookieStore.get(SESSION_COOKIE)?.value);
}

export async function requireSession(): Promise<SessionUser> {
  const session = await getSession();
  if (!session) {
    throw new Error("UNAUTHORIZED");
  }
  return session;
}
