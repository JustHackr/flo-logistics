import { describe, expect, it } from "vitest";
import { canAccessPath, defaultHomeForRole } from "./roles";

describe("rbac paths", () => {
  it("allows admin everywhere", () => {
    expect(canAccessPath("ADMIN", "/admin/mockup-data")).toBe(true);
    expect(canAccessPath("ADMIN", "/connectors")).toBe(true);
  });

  it("scopes driver away from admin and vehicles", () => {
    expect(canAccessPath("DRIVER", "/routing/plan")).toBe(true);
    expect(canAccessPath("DRIVER", "/vehicles")).toBe(false);
    expect(canAccessPath("DRIVER", "/admin/mockup-data")).toBe(false);
  });

  it("scopes warehouse to CV and orders", () => {
    expect(canAccessPath("WAREHOUSE", "/computer-vision/load-detection")).toBe(
      true
    );
    expect(canAccessPath("WAREHOUSE", "/routing/orders")).toBe(true);
    expect(canAccessPath("WAREHOUSE", "/ai/settings")).toBe(false);
  });

  it("returns sensible home routes", () => {
    expect(defaultHomeForRole("DRIVER")).toBe("/routing/plan");
    expect(defaultHomeForRole("WAREHOUSE")).toBe(
      "/computer-vision/load-detection"
    );
  });
});
