import { prisma } from "@/lib/prisma";
import {
  delayPredictionMetrics,
  scoreOrderSlaRisk,
  type SlaRiskLevel,
  type SlaRiskResult,
} from "@/lib/routing/sla-risk";
import { calculateDti } from "@/lib/routing/dti";

export type OrderWithSlaRisk = {
  orderId: string;
  recipientAddress: string;
  status: string;
  receivedAt: string | null;
  etaAt: string | null;
  sla: SlaRiskResult;
};

export type SlaAlertsBundle = {
  generatedAt: string;
  atRisk: OrderWithSlaRisk[];
  byLevel: Record<SlaRiskLevel, number>;
  modelPerformance: {
    sampleSize: number;
    maeMin: number | null;
    hitRate: number | null;
  };
  all: OrderWithSlaRisk[];
};

export async function getSlaAlertsBundle(): Promise<SlaAlertsBundle> {
  const [warehouse, orders] = await Promise.all([
    prisma.warehouse.findFirst({ orderBy: { createdAt: "asc" } }),
    prisma.order.findMany({
      orderBy: { createdAt: "desc" },
      include: { routeStop: true },
    }),
  ]);

  const wh = warehouse
    ? { lat: warehouse.lat, lng: warehouse.lng }
    : { lat: -6.244264, lng: 106.79905 };

  const all: OrderWithSlaRisk[] = orders.map((o) => {
    const sla = scoreOrderSlaRisk({
      warehouse: wh,
      stop: { lat: o.lat, lng: o.lng },
      status: o.status,
      receivedAt: o.receivedAt,
      etaAt: o.etaAt ?? o.routeStop?.etaAt ?? null,
    });
    return {
      orderId: o.id,
      recipientAddress: o.recipientAddress,
      status: o.status,
      receivedAt: o.receivedAt?.toISOString() ?? null,
      etaAt: (o.etaAt ?? o.routeStop?.etaAt)?.toISOString() ?? null,
      sla,
    };
  });

  const atRisk = all
    .filter(
      (o) =>
        o.status !== "DELIVERED" &&
        (o.sla.level === "high" || o.sla.level === "critical" || o.sla.level === "medium")
    )
    .sort((a, b) => b.sla.score - a.sla.score)
    .slice(0, 12);

  const byLevel: Record<SlaRiskLevel, number> = {
    low: 0,
    medium: 0,
    high: 0,
    critical: 0,
  };
  for (const o of all) {
    if (o.status === "DELIVERED") continue;
    byLevel[o.sla.level] += 1;
  }

  const delaySamples = orders.map((o) => {
    const sla = scoreOrderSlaRisk({
      warehouse: wh,
      stop: { lat: o.lat, lng: o.lng },
      status: o.status,
      receivedAt: o.receivedAt,
      etaAt: o.etaAt ?? o.routeStop?.etaAt ?? null,
    });
    const dti = calculateDti({
      receivedAt: o.receivedAt,
      plannedEtaAt: o.etaAt ?? o.routeStop?.etaAt ?? null,
      deliveredAt: o.deliveredAt,
    });
    return {
      predictedDelayMin: sla.predictedDelayMin,
      actualSlackMin: dti.status === "computed" ? dti.slackMin : null,
    };
  });

  return {
    generatedAt: new Date().toISOString(),
    atRisk,
    byLevel,
    modelPerformance: delayPredictionMetrics(delaySamples),
    all,
  };
}
