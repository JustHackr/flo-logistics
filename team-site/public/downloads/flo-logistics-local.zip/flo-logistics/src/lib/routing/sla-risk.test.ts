import { describe, expect, it } from "vitest";
import { scoreOrderSlaRisk, slaLevelFromScore } from "./sla-risk";
import { buildCarbonAnalytics } from "./carbon-analytics";

describe("sla risk", () => {
  it("scores delivered orders as low risk", () => {
    const result = scoreOrderSlaRisk({
      warehouse: { lat: -6.244, lng: 106.799 },
      stop: { lat: -6.2, lng: 106.82 },
      status: "DELIVERED",
      receivedAt: new Date(),
    });
    expect(result.level).toBe("low");
    expect(result.score).toBeLessThan(20);
  });

  it("raises risk for old undelivered far orders", () => {
    const receivedAt = new Date();
    receivedAt.setHours(receivedAt.getHours() - 5);
    const result = scoreOrderSlaRisk({
      warehouse: { lat: -6.244, lng: 106.799 },
      stop: { lat: -6.1, lng: 106.9 },
      status: "RECEIVED",
      receivedAt,
      now: new Date(),
    });
    expect(result.score).toBeGreaterThan(40);
    expect(["medium", "high", "critical"]).toContain(result.level);
  });

  it("maps scores to levels", () => {
    expect(slaLevelFromScore(10)).toBe("low");
    expect(slaLevelFromScore(50)).toBe("medium");
    expect(slaLevelFromScore(70)).toBe("high");
    expect(slaLevelFromScore(90)).toBe("critical");
  });
});

describe("carbon analytics", () => {
  it("computes savings vs naive baseline", () => {
    const result = buildCarbonAnalytics([
      {
        routePlanId: "r1",
        driverName: "Andi",
        vehicleName: "Van",
        engineType: "gasoline",
        distanceKm: 20,
        emissionsKg: 3,
        stops: 4,
      },
    ]);
    expect(result.totals.emissionsKg).toBe(3);
    expect(result.totals.naiveEmissionsKg).toBeGreaterThan(3);
    expect(result.totals.savingsKg).toBeGreaterThan(0);
    expect(result.rows[0].perStopKg).toBeCloseTo(0.75, 5);
  });
});
