import { distanceKm, type LatLng } from "@/lib/routing/geo";
import {
  DELIVERY_STOP_SERVICE_MIN,
  getJakartaTrafficMultiplier,
  JAKARTA_ROAD_DISTANCE_FACTOR,
} from "@/lib/routing/traffic";

export type SlaRiskLevel = "low" | "medium" | "high" | "critical";

export type SlaRiskResult = {
  score: number; // 0–100, higher = more risk of missing SLA
  level: SlaRiskLevel;
  predictedTravelMin: number;
  predictedTotalMin: number;
  slaTargetMin: number;
  predictedDelayMin: number;
  factors: {
    distanceKm: number;
    trafficMultiplier: number;
    ageHours: number;
    statusWeight: number;
  };
  reasons: string[];
};

/** Default same-day urban SLA window from receive → deliver (minutes). */
export const DEFAULT_SLA_TARGET_MIN = 180;

const STATUS_WEIGHT: Record<string, number> = {
  RECEIVED: 0.15,
  PREPARING: 0.25,
  ON_ROUTE: 0.45,
  DELIVERED: 0,
};

export function slaLevelFromScore(score: number): SlaRiskLevel {
  if (score >= 80) return "critical";
  if (score >= 60) return "high";
  if (score >= 35) return "medium";
  return "low";
}

/**
 * Heuristic SLA risk for an order using distance, Jakarta traffic, age in pipeline,
 * and current status. Speaks the case-brief language (SLA risk scores + delay prediction)
 * without requiring labeled historical delay data.
 */
export function scoreOrderSlaRisk(input: {
  warehouse: LatLng;
  stop: LatLng;
  status: string;
  receivedAt: Date | null;
  etaAt?: Date | null;
  now?: Date;
  slaTargetMin?: number;
}): SlaRiskResult {
  const now = input.now ?? new Date();
  const slaTargetMin = input.slaTargetMin ?? DEFAULT_SLA_TARGET_MIN;
  const straight = distanceKm(input.warehouse, input.stop);
  const roadKm = straight * JAKARTA_ROAD_DISTANCE_FACTOR;
  const traffic = getJakartaTrafficMultiplier(now);
  // Assume ~14 km/h effective urban last-mile baseline, then apply traffic.
  const baseSpeedKmh = 14 / traffic;
  const travelMin = (roadKm / Math.max(baseSpeedKmh, 4)) * 60;
  const predictedTotalMin = travelMin + DELIVERY_STOP_SERVICE_MIN;

  const ageHours = input.receivedAt
    ? Math.max(0, (now.getTime() - input.receivedAt.getTime()) / 3_600_000)
    : 0;
  const statusWeight = STATUS_WEIGHT[input.status] ?? 0.2;

  // Age pressure: every hour in pipeline beyond 1h adds risk.
  const ageScore = Math.min(40, Math.max(0, (ageHours - 1) * 12));
  // Travel vs SLA window.
  const travelPressure = Math.min(35, (predictedTotalMin / slaTargetMin) * 35);
  const statusScore = statusWeight * 25;

  let etaPressure = 0;
  if (input.etaAt && input.status !== "DELIVERED") {
    const slackMin = (input.etaAt.getTime() - now.getTime()) / 60_000;
    if (slackMin < 0) etaPressure = Math.min(30, Math.abs(slackMin) / 2);
    else if (slackMin < 20) etaPressure = 12;
  }

  const raw =
    input.status === "DELIVERED"
      ? 5
      : ageScore + travelPressure + statusScore + etaPressure;
  const score = Math.round(Math.min(100, Math.max(0, raw)));
  const predictedDelayMin = Math.max(0, Math.round(predictedTotalMin + ageHours * 15 - slaTargetMin));

  const reasons: string[] = [];
  if (traffic >= 1.7) reasons.push("Jakarta peak traffic window");
  if (ageHours >= 2) reasons.push(`In pipeline ${ageHours.toFixed(1)}h`);
  if (roadKm >= 8) reasons.push("Long last-mile distance");
  if (etaPressure >= 12) reasons.push("ETA at risk or overdue");
  if (input.status === "RECEIVED" || input.status === "PREPARING") {
    reasons.push("Not yet dispatched");
  }
  if (reasons.length === 0) reasons.push("Within normal operating band");

  return {
    score,
    level: slaLevelFromScore(score),
    predictedTravelMin: Math.round(travelMin),
    predictedTotalMin: Math.round(predictedTotalMin),
    slaTargetMin,
    predictedDelayMin,
    factors: {
      distanceKm: Math.round(roadKm * 100) / 100,
      trafficMultiplier: traffic,
      ageHours: Math.round(ageHours * 10) / 10,
      statusWeight,
    },
    reasons,
  };
}

export function delayPredictionMetrics(samples: Array<{ predictedDelayMin: number; actualSlackMin: number | null }>) {
  const withActual = samples.filter((s) => s.actualSlackMin != null) as Array<{
    predictedDelayMin: number;
    actualSlackMin: number;
  }>;
  if (withActual.length === 0) {
    return { sampleSize: 0, maeMin: null as number | null, hitRate: null as number | null };
  }
  const absErrors = withActual.map((s) =>
    Math.abs(s.predictedDelayMin - Math.max(0, -s.actualSlackMin))
  );
  const maeMin = Math.round((absErrors.reduce((a, b) => a + b, 0) / absErrors.length) * 10) / 10;
  const hits = withActual.filter((s) => {
    const actualDelay = Math.max(0, -s.actualSlackMin);
    const predLate = s.predictedDelayMin > 10;
    const actualLate = actualDelay > 10;
    return predLate === actualLate;
  }).length;
  return {
    sampleSize: withActual.length,
    maeMin,
    hitRate: Math.round((hits / withActual.length) * 100),
  };
}
