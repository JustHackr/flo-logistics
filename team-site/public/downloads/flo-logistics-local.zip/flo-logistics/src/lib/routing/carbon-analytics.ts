import { CO2_KG_PER_KM, estimateEmissionsKg } from "@/lib/routing/emissions";
import type { EngineType } from "@/lib/types";

export type CarbonRouteRow = {
  routePlanId: string;
  driverName: string;
  vehicleName: string;
  engineType: string;
  distanceKm: number;
  emissionsKg: number;
  naiveEmissionsKg: number;
  savingsKg: number;
  savingsPercent: number;
  perStopKg: number;
  stops: number;
};

/**
 * Compare optimized route emissions vs a naive "direct round-trip per stop"
 * baseline (approx 1.25× distance) to show carbon savings for the case brief.
 */
export function buildCarbonAnalytics(
  routes: Array<{
    routePlanId: string;
    driverName: string;
    vehicleName: string;
    engineType: string;
    distanceKm: number;
    emissionsKg: number;
    stops: number;
  }>
): {
  totals: {
    distanceKm: number;
    emissionsKg: number;
    naiveEmissionsKg: number;
    savingsKg: number;
    savingsPercent: number;
    perShipmentKg: number;
    shipments: number;
  };
  rows: CarbonRouteRow[];
} {
  const rows: CarbonRouteRow[] = routes.map((r) => {
    const engine = (r.engineType as EngineType) || "gasoline";
    const naiveDistance = r.distanceKm * 1.25;
    const naiveEmissionsKg =
      r.emissionsKg > 0
        ? Math.round(estimateEmissionsKg(engine, naiveDistance) * 100) / 100
        : Math.round((naiveDistance * (CO2_KG_PER_KM[engine] ?? 0.15)) * 100) / 100;
    const emissionsKg =
      r.emissionsKg > 0
        ? r.emissionsKg
        : estimateEmissionsKg(engine, r.distanceKm);
    const savingsKg = Math.max(0, Math.round((naiveEmissionsKg - emissionsKg) * 100) / 100);
    const savingsPercent =
      naiveEmissionsKg > 0
        ? Math.round((savingsKg / naiveEmissionsKg) * 1000) / 10
        : 0;
    return {
      routePlanId: r.routePlanId,
      driverName: r.driverName,
      vehicleName: r.vehicleName,
      engineType: r.engineType,
      distanceKm: r.distanceKm,
      emissionsKg,
      naiveEmissionsKg,
      savingsKg,
      savingsPercent,
      perStopKg:
        r.stops > 0 ? Math.round((emissionsKg / r.stops) * 1000) / 1000 : 0,
      stops: r.stops,
    };
  });

  const distanceKm = rows.reduce((s, r) => s + r.distanceKm, 0);
  const emissionsKg = rows.reduce((s, r) => s + r.emissionsKg, 0);
  const naiveEmissionsKg = rows.reduce((s, r) => s + r.naiveEmissionsKg, 0);
  const savingsKg = Math.max(0, Math.round((naiveEmissionsKg - emissionsKg) * 100) / 100);
  const shipments = rows.reduce((s, r) => s + r.stops, 0);

  return {
    totals: {
      distanceKm: Math.round(distanceKm * 100) / 100,
      emissionsKg: Math.round(emissionsKg * 100) / 100,
      naiveEmissionsKg: Math.round(naiveEmissionsKg * 100) / 100,
      savingsKg,
      savingsPercent:
        naiveEmissionsKg > 0
          ? Math.round((savingsKg / naiveEmissionsKg) * 1000) / 10
          : 0,
      perShipmentKg:
        shipments > 0 ? Math.round((emissionsKg / shipments) * 1000) / 1000 : 0,
      shipments,
    },
    rows,
  };
}
