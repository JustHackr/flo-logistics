"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  TrendingDown,
  Wallet,
  CalendarClock,
  ShieldAlert,
  Gauge,
  ExternalLink,
  Library,
  Route,
  Truck,
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { RiskBadge } from "@/components/risk-badge";
import { formatCurrency, formatNumber } from "@/lib/format";
import {
  ENGINE_COST_MODIFIERS,
  ENGINE_ODOMETER_MODIFIERS,
  PLANNING_PENALTY_PER_DAY,
  RISK_THRESHOLDS,
  VQI_WEIGHTS,
} from "@/lib/vqi";
import type { VehicleWithAnalysis } from "@/lib/types";
import { useI18n } from "@/components/i18n/use-i18n";

const BENEFITS = [
  {
    icon: TrendingDown,
    title: "reduceDowntimeTitle",
    body: "reduceDowntimeBody",
  },
  {
    icon: Wallet,
    title: "optimizeCostTitle",
    body: "optimizeCostBody",
  },
  {
    icon: CalendarClock,
    title: "planAheadTitle",
    body: "planAheadBody",
  },
  {
    icon: ShieldAlert,
    title: "prioritizeRiskTitle",
    body: "prioritizeRiskBody",
  },
];

const INDUSTRY_REFERENCES = [
  {
    title: "APWA Fleet Replacement Scoring Standard (RTA Fleet)",
    note: "Scores vehicles on age, mileage, maintenance cost vs. purchase price, service count, and condition — the same factor family as the VQI.",
    url: "https://docs.rtafleet.com/rta-manual/vehicle-replacement-scoring-report/",
  },
  {
    title: "AssetWorks M5 — Replacement Model Prioritization",
    note: "Weighted factors summing to 100 and normalized against the fleet/category average, directly analogous to the VQI weights and cost-vs-fleet-average logic.",
    url: "https://fleetfocus.assetworks.com/m5help/webhelp/Asset_Management/Unit_Replacement/Replacement_Model_Prioritization.htm",
  },
  {
    title: "San Bernardino Municipal Water Dept. — Vehicle & Equipment Replacement Policy",
    note: "Public policy: one point per 20% of expected service life; reliability scored against average maintenance cost per mile of the class.",
    url: "https://sbmwd.org/DocumentCenter/View/267/Policy-51-035-Vehicle-and-Equipment-Replacement-Policy-PDF",
  },
];

const ACADEMIC_REFERENCES = [
  {
    title: "Predictive Maintenance in the Automotive Sector: A Literature Review (2021)",
    note: "Surveys health-index construction, health-stage division, and Remaining Useful Life (RUL) estimation for vehicles.",
    url: "https://www.researchgate.net/publication/357557268_Predictive_Maintenance_in_the_Automotive_Sector_A_Literature_Review",
  },
  {
    title: "Baraldi et al. — Multi-objective optimization for a health indicator (Polimi)",
    note: "Formal method for defining a component health indicator with desirable properties such as monotonicity and trendability.",
    url: "https://re.public.polimi.it/bitstream/11311/1077977/2/11311-1077977_Baraldi.pdf",
  },
  {
    title: "A Deep Learning Feature Fusion Based Health Index Construction Method (IEEE Trans. Reliability, 2022)",
    note: "Machine-learning composite health index for prognostics and RUL — the direction a future ML-based VQI could take.",
    url: "https://doi.org/10.1109/tr.2022.3215757",
  },
];

const METRIC_ROWS = [
  {
    factor: "vehicleAge",
    weight: VQI_WEIGHTS.age,
    measures: "vehicleAgeMeasures",
    formula: "(age / lifetime years) × 30",
  },
  {
    factor: "odometerWear",
    weight: VQI_WEIGHTS.odometer,
    measures: "odometerWearMeasures",
    formula: "(odometer / expected km) × 30 × engine modifier",
  },
  {
    factor: "maintenanceCost",
    weight: VQI_WEIGHTS.cost,
    measures: "maintenanceCostMeasures",
    formula: "(cost × engine modifier / fleet avg) × 20",
  },
  {
    factor: "maintenancePlanning",
    weight: VQI_WEIGHTS.planning,
    measures: "maintenancePlanningMeasures",
    formula: "days overdue × 0.5",
  },
];

function round1(value: number) {
  return Math.round(value * 10) / 10;
}

function daysOverdue(nextMaintenance: string | null) {
  if (!nextMaintenance) return 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const next = new Date(nextMaintenance);
  next.setHours(0, 0, 0, 0);
  return Math.max(
    0,
    Math.floor((today.getTime() - next.getTime()) / (1000 * 60 * 60 * 24))
  );
}

export function MethodologyClient({
  vehicles,
  fleetAvgMaintenanceCost,
}: {
  vehicles: VehicleWithAnalysis[];
  fleetAvgMaintenanceCost: number;
}) {
  const { t } = useI18n();
  const [selectedId, setSelectedId] = useState(vehicles[0]?.id ?? "");
  const selected = useMemo(
    () => vehicles.find((v) => v.id === selectedId) ?? vehicles[0],
    [vehicles, selectedId]
  );

  const steps = useMemo(() => {
    if (!selected) return null;

    const odoModifier =
      ENGINE_ODOMETER_MODIFIERS[selected.engineType] ?? 1;
    const costModifier = ENGINE_COST_MODIFIERS[selected.engineType] ?? 1;
    const normalizedCost =
      fleetAvgMaintenanceCost > 0
        ? (selected.maintenanceCostUnit * costModifier) / fleetAvgMaintenanceCost
        : 1;
    const overdue = daysOverdue(selected.nextMaintenanceDate);

    return [
      {
        factor: t("fleet.methodology.vehicleAge"),
        detail: `(${formatNumber(selected.vehicleAgeYears, 1)} ${t("fleet.methodology.yearsShort")} ÷ ${formatNumber(
          selected.vehicleLifetimeYears,
          1
        )} ${t("fleet.methodology.yearsShort")}) × ${VQI_WEIGHTS.age}`,
        raw: round1(
          (selected.vehicleAgeYears / selected.vehicleLifetimeYears) *
            VQI_WEIGHTS.age
        ),
        penalty: selected.penalties.age,
        max: VQI_WEIGHTS.age,
      },
      {
        factor: t("fleet.methodology.odometerWear"),
        detail: `(${formatNumber(selected.odometerKm)} ÷ ${formatNumber(
          selected.expectedLifetimeKm
        )}) × ${VQI_WEIGHTS.odometer} × ${odoModifier}`,
        raw: round1(
          (selected.odometerKm / selected.expectedLifetimeKm) *
            VQI_WEIGHTS.odometer *
            odoModifier
        ),
        penalty: selected.penalties.odometer,
        max: VQI_WEIGHTS.odometer,
      },
      {
        factor: t("fleet.methodology.maintenanceCost"),
        detail: `(${formatCurrency(selected.maintenanceCostUnit)} × ${costModifier} ÷ ${formatCurrency(
          Math.round(fleetAvgMaintenanceCost)
        )}) × ${VQI_WEIGHTS.cost}`,
        raw: round1(normalizedCost * VQI_WEIGHTS.cost),
        penalty: selected.penalties.cost,
        max: VQI_WEIGHTS.cost,
      },
      {
        factor: t("fleet.methodology.maintenancePlanning"),
        detail:
          overdue > 0
            ? t("fleet.methodology.daysOverdue", { count: overdue, rate: PLANNING_PENALTY_PER_DAY })
            : t("fleet.methodology.notOverdue"),
        raw: round1(overdue * PLANNING_PENALTY_PER_DAY),
        penalty: selected.penalties.planning,
        max: VQI_WEIGHTS.planning,
      },
    ];
  }, [selected, fleetAvgMaintenanceCost, t]);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">
          {t("fleet.methodology.title")}
        </h2>
        <p className="text-muted-foreground">
          {t("fleet.methodology.subtitle")}
        </p>
      </div>

      <section className="space-y-3">
        <h3 className="text-lg font-semibold">{t("fleet.methodology.whyPredictive")}</h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {BENEFITS.map((benefit) => (
            <Card key={benefit.title}>
              <CardHeader className="pb-2">
                <benefit.icon className="h-6 w-6 text-primary" />
                <CardTitle className="text-base">{t(`fleet.methodology.${benefit.title}`)}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{t(`fleet.methodology.${benefit.body}`)}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="space-y-3">
        <h3 className="text-lg font-semibold">{t("fleet.methodology.vqiTitle")}</h3>
        <p className="text-sm text-muted-foreground">
          {t("fleet.methodology.vqiDescription")}
        </p>
        <Card>
          <CardContent className="pt-6">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("fleet.methodology.factor")}</TableHead>
                  <TableHead className="w-24">{t("fleet.methodology.maxPoints")}</TableHead>
                  <TableHead>{t("fleet.methodology.whatItMeasures")}</TableHead>
                  <TableHead>{t("fleet.methodology.penaltyFormula")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {METRIC_ROWS.map((row) => (
                  <TableRow key={row.factor}>
                    <TableCell className="font-medium">{t(`fleet.methodology.${row.factor}`)}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{t("fleet.methodology.points", { count: row.weight })}</Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {t(`fleet.methodology.${row.measures}`)}
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {row.formula}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">{t("fleet.methodology.formulaTitle")}</CardTitle>
            <CardDescription>
              {t("fleet.methodology.formulaDescription")}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <pre className="overflow-x-auto rounded-lg bg-muted p-4 font-mono text-sm">
{`VQI = 100 − (age + odometer + cost + planning)

max penalties: 30 + 30 + 20 + 20 = 100`}
            </pre>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Badge variant="destructive">{t("fleet.methodology.highRisk")}</Badge>
                <span className="text-muted-foreground">
                  VQI &lt; {RISK_THRESHOLDS.highBelow}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{t("fleet.methodology.mediumRisk")}</Badge>
                <span className="text-muted-foreground">
                  {RISK_THRESHOLDS.highBelow} – {RISK_THRESHOLDS.lowAbove}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Badge>{t("fleet.methodology.lowRisk")}</Badge>
                <span className="text-muted-foreground">
                  VQI &gt; {RISK_THRESHOLDS.lowAbove}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">{t("fleet.methodology.engineModifiers")}</CardTitle>
            <CardDescription>
              {t("fleet.methodology.engineModifiersDescription")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("fleet.methodology.engine")}</TableHead>
                  <TableHead>{t("fleet.methodology.odometerMultiplier")}</TableHead>
                  <TableHead>{t("fleet.methodology.costMultiplier")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(["gasoline", "diesel", "ev"] as const).map((engine) => (
                  <TableRow key={engine}>
                    <TableCell className="font-medium uppercase">
                      {t(`fleet.methodology.engine_${engine}`)}
                    </TableCell>
                    <TableCell>{ENGINE_ODOMETER_MODIFIERS[engine]}</TableCell>
                    <TableCell>{ENGINE_COST_MODIFIERS[engine]}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="mt-3 text-xs text-muted-foreground">
              {t("fleet.methodology.engineNote")}
            </p>
          </CardContent>
        </Card>
      </section>

      <section className="space-y-3">
        <h3 className="flex items-center gap-2 text-lg font-semibold">
          <Truck className="h-5 w-5 text-primary" />
          {t("fleet.methodology.routingDispatch")}
        </h3>
        <p className="text-sm text-muted-foreground">
          {t("fleet.methodology.routingDispatchDescription")}{" "}
          <Link href="/routing/drivers" className="font-medium text-primary hover:underline">
            {t("fleet.methodology.driversLink")}
          </Link>
          ; {t("fleet.methodology.formulasAt")}{" "}
          <Link href="/routing/methodology" className="font-medium text-primary hover:underline">
            {t("fleet.methodology.routingGuideLink")}
          </Link>
          .
        </p>
        <Card>
          <CardContent className="flex items-start gap-3 pt-6 text-sm">
            <Route className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
            <div className="space-y-1 text-muted-foreground">
              <p>
                <span className="font-medium text-foreground">{t("fleet.methodology.selectionRuleLabel")}</span>{" "}
                {t("fleet.methodology.selectionRule")}
              </p>
              <p>
                <span className="font-medium text-foreground">{t("fleet.methodology.demoEvLabel")}</span>{" "}
                {t("fleet.methodology.demoEv")}
              </p>
            </div>
          </CardContent>
        </Card>
      </section>

      <section className="space-y-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="flex items-center gap-2 text-lg font-semibold">
              <Gauge className="h-5 w-5 text-primary" />
              {t("fleet.methodology.liveCalculation")}
            </h3>
            <p className="text-sm text-muted-foreground">
              {t("fleet.methodology.liveCalculationDescription")}
            </p>
          </div>
          {selected && (
            <Select value={selectedId} onValueChange={(v) => setSelectedId(v ?? selectedId)}>
              <SelectTrigger className="w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {vehicles.map((v) => (
                  <SelectItem key={v.id} value={v.id}>
                    {v.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {selected && steps && (
          <Card>
            <CardHeader>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <CardTitle className="text-base">{selected.name}</CardTitle>
                <RiskBadge risk={selected.riskLevel} vqi={selected.vqi} />
              </div>
              <CardDescription className="uppercase">
                {selected.vehicleType} · {selected.engineType} ·{" "}
                {formatNumber(selected.odometerKm)} km ·{" "}
                {formatNumber(selected.vehicleAgeYears, 1)} {t("fleet.methodology.yearsShort")}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t("fleet.methodology.factor")}</TableHead>
                    <TableHead>{t("fleet.methodology.calculation")}</TableHead>
                    <TableHead className="text-right">{t("fleet.methodology.raw")}</TableHead>
                    <TableHead className="text-right">{t("fleet.methodology.penaltyMax")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {steps.map((step) => (
                    <TableRow key={step.factor}>
                      <TableCell className="font-medium">{step.factor}</TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">
                        {step.detail}
                      </TableCell>
                      <TableCell className="text-right">{step.raw}</TableCell>
                      <TableCell className="text-right">
                        <span className="font-semibold text-destructive">
                          −{step.penalty}
                        </span>{" "}
                        <span className="text-xs text-muted-foreground">
                          / {step.max}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                  <TableRow>
                    <TableCell colSpan={3} className="text-right font-medium">
                      {t("fleet.methodology.totalPenalties")}
                    </TableCell>
                    <TableCell className="text-right font-semibold text-destructive">
                      −{selected.penalties.total}
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>

              <div className="flex flex-wrap items-center gap-4 rounded-lg bg-muted p-4">
                <span className="font-mono text-sm">
                  VQI = 100 − {selected.penalties.total} ={" "}
                  <span className="text-lg font-bold text-foreground">
                    {selected.vqi}
                  </span>
                </span>
                <RiskBadge risk={selected.riskLevel} />
                <span className="text-sm text-muted-foreground">
                  {t("fleet.methodology.estimatedServiceCost", { amount: formatCurrency(selected.estimatedCost) })}
                </span>
              </div>
              <p className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground">{t("fleet.methodology.recommendedAction")}</span>{" "}
                {selected.recommendedAction}
              </p>
            </CardContent>
          </Card>
        )}
      </section>

      <section className="space-y-3">
        <h3 className="flex items-center gap-2 text-lg font-semibold">
          <Library className="h-5 w-5 text-primary" />
          {t("fleet.methodology.references")}
        </h3>
        <p className="text-sm text-muted-foreground">
          {t("fleet.methodology.referencesDescription")}
        </p>
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("fleet.methodology.industryModels")}</CardTitle>
              <CardDescription>
                {t("fleet.methodology.industryModelsDescription")}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {INDUSTRY_REFERENCES.map((ref) => (
                <div key={ref.url} className="space-y-1">
                  <a
                    href={ref.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-1.5 text-sm font-medium text-primary hover:underline"
                  >
                    <ExternalLink className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    {ref.title}
                  </a>
                  <p className="text-xs text-muted-foreground">{ref.note}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t("fleet.methodology.academicLiterature")}</CardTitle>
              <CardDescription>
                {t("fleet.methodology.academicLiteratureDescription")}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {ACADEMIC_REFERENCES.map((ref) => (
                <div key={ref.url} className="space-y-1">
                  <a
                    href={ref.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-1.5 text-sm font-medium text-primary hover:underline"
                  >
                    <ExternalLink className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    {ref.title}
                  </a>
                  <p className="text-xs text-muted-foreground">{ref.note}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
