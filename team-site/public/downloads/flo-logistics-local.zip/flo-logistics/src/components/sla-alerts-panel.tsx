"use client";

import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useI18n } from "@/components/i18n/use-i18n";
import { cn } from "@/lib/utils";
import type { SlaAlertsBundle } from "@/lib/sla-alerts";
import type { SlaRiskLevel } from "@/lib/routing/sla-risk";

function levelClass(level: SlaRiskLevel) {
  switch (level) {
    case "critical":
      return "border-red-500/40 bg-red-500/10 text-red-700 dark:text-red-300";
    case "high":
      return "border-orange-500/40 bg-orange-500/10 text-orange-700 dark:text-orange-300";
    case "medium":
      return "border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300";
    default:
      return "border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300";
  }
}

export function SlaAlertsPanel({ data }: { data: SlaAlertsBundle }) {
  const { t } = useI18n();
  const openRisk =
    data.byLevel.medium + data.byLevel.high + data.byLevel.critical;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <CardTitle className="text-base">{t("sla.title")}</CardTitle>
            <p className="mt-1 text-sm text-muted-foreground">
              {t("sla.subtitle")}
            </p>
          </div>
          <Badge variant="outline">{t("sla.openRisk", { count: openRisk })}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {(["critical", "high", "medium", "low"] as SlaRiskLevel[]).map(
            (level) => (
              <div
                key={level}
                className={cn(
                  "rounded-xl border px-3 py-2",
                  levelClass(level)
                )}
              >
                <p className="text-[10px] font-medium uppercase tracking-wide opacity-80">
                  {t(`sla.levels.${level}`)}
                </p>
                <p className="text-xl font-semibold">{data.byLevel[level]}</p>
              </div>
            )
          )}
        </div>

        {data.modelPerformance.sampleSize > 0 && (
          <div className="rounded-xl border border-border/70 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
            {t("sla.modelPerf", {
              samples: data.modelPerformance.sampleSize,
              mae: data.modelPerformance.maeMin ?? "—",
              hit: data.modelPerformance.hitRate ?? "—",
            })}
          </div>
        )}

        <ul className="divide-y divide-border/60 rounded-xl border border-border/70">
          {data.atRisk.length === 0 && (
            <li className="px-3 py-4 text-sm text-muted-foreground">
              {t("sla.noneAtRisk")}
            </li>
          )}
          {data.atRisk.map((item) => (
            <li
              key={item.orderId}
              className="flex flex-col gap-1 px-3 py-3 sm:flex-row sm:items-center sm:justify-between"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">
                  {item.recipientAddress}
                </p>
                <p className="text-xs text-muted-foreground">
                  {t("sla.predicted", {
                    minutes: item.sla.predictedTotalMin,
                    delay: item.sla.predictedDelayMin,
                  })}
                  {" · "}
                  {item.sla.reasons.slice(0, 2).join(" · ")}
                </p>
              </div>
              <Badge
                variant="outline"
                className={cn("shrink-0", levelClass(item.sla.level))}
              >
                {t(`sla.levels.${item.sla.level}`)} · {item.sla.score}
              </Badge>
            </li>
          ))}
        </ul>

        <div className="flex justify-end">
          <Link
            href="/routing/orders"
            className="text-sm font-medium text-primary hover:underline"
          >
            {t("sla.viewOrders")}
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
