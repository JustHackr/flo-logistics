"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useI18n } from "@/components/i18n/use-i18n";
import type { buildCarbonAnalytics } from "@/lib/routing/carbon-analytics";

type CarbonData = ReturnType<typeof buildCarbonAnalytics>;

export function CarbonAnalyticsPanel({ data }: { data: CarbonData }) {
  const { t } = useI18n();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">{t("carbon.title")}</CardTitle>
        <p className="text-sm text-muted-foreground">{t("carbon.subtitle")}</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-xl border bg-muted/30 px-3 py-2">
            <p className="text-xs text-muted-foreground">{t("carbon.totalEmissions")}</p>
            <p className="text-xl font-semibold">{data.totals.emissionsKg} kg</p>
          </div>
          <div className="rounded-xl border bg-muted/30 px-3 py-2">
            <p className="text-xs text-muted-foreground">{t("carbon.savings")}</p>
            <p className="text-xl font-semibold">
              {data.totals.savingsKg} kg ({data.totals.savingsPercent}%)
            </p>
          </div>
          <div className="rounded-xl border bg-muted/30 px-3 py-2">
            <p className="text-xs text-muted-foreground">{t("carbon.perShipment")}</p>
            <p className="text-xl font-semibold">{data.totals.perShipmentKg} kg</p>
          </div>
          <div className="rounded-xl border bg-muted/30 px-3 py-2">
            <p className="text-xs text-muted-foreground">
              {t("carbon.shipments", { count: data.totals.shipments })}
            </p>
            <p className="text-xl font-semibold">{data.totals.distanceKm} km</p>
          </div>
        </div>

        <div className="overflow-x-auto rounded-xl border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Driver</TableHead>
                <TableHead>Vehicle</TableHead>
                <TableHead className="text-right">Distance km</TableHead>
                <TableHead className="text-right">CO₂ kg</TableHead>
                <TableHead className="text-right">Naive kg</TableHead>
                <TableHead className="text-right">Saved</TableHead>
                <TableHead className="text-right">Per stop</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.rows.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-muted-foreground">
                    —
                  </TableCell>
                </TableRow>
              )}
              {data.rows.map((row) => (
                <TableRow key={row.routePlanId}>
                  <TableCell className="font-medium">{row.driverName}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {row.vehicleName}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {row.distanceKm.toFixed(1)}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {row.emissionsKg}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {row.naiveEmissionsKg}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {row.savingsKg} ({row.savingsPercent}%)
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {row.perStopKg}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
