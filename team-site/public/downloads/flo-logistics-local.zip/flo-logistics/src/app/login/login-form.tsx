"use client";

import * as React from "react";
import { useActionState } from "react";
import { loginAction, quickLoginAction, type LoginState } from "@/app/actions/auth";
import { DEMO_ACCOUNTS } from "@/lib/auth/roles";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BrandPartners } from "@/components/brand-partners";
import { LanguageToggle } from "@/components/i18n/language-toggle";
import { useI18n } from "@/components/i18n/use-i18n";
import { cn } from "@/lib/utils";
import { ShieldCheck, Truck, Warehouse, LayoutDashboard } from "lucide-react";

const roleIcons = {
  ADMIN: ShieldCheck,
  OPS_MANAGER: LayoutDashboard,
  DRIVER: Truck,
  WAREHOUSE: Warehouse,
} as const;

export function LoginForm() {
  const { t } = useI18n();
  const [state, formAction, pending] = useActionState<LoginState, FormData>(
    loginAction,
    undefined
  );
  const [quickError, setQuickError] = React.useState<string | null>(null);
  const [quickPending, setQuickPending] = React.useState<string | null>(null);

  async function handleQuickLogin(email: string) {
    setQuickError(null);
    setQuickPending(email);
    try {
      const result = await quickLoginAction(email);
      if (result?.error) setQuickError(result.error);
    } catch {
      // redirect throws — ignore
    } finally {
      setQuickPending(null);
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-8 px-4 py-10 md:py-16">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">
            {t("auth.demoBadge")}
          </p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight text-primary">
            {t("chrome.appName")}
          </h1>
          <p className="mt-1 max-w-xl text-sm text-muted-foreground">
            {t("auth.subtitle")}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <LanguageToggle />
          <BrandPartners className="hidden sm:flex" />
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <section className="rounded-2xl border border-border/80 bg-card p-6 shadow-sm">
          <h2 className="text-lg font-semibold">{t("auth.quickTitle")}</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {t("auth.quickHint")}
          </p>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            {DEMO_ACCOUNTS.map((account) => {
              const Icon = roleIcons[account.role];
              const busy = quickPending === account.email;
              return (
                <button
                  key={account.email}
                  type="button"
                  disabled={!!quickPending}
                  onClick={() => handleQuickLogin(account.email)}
                  className={cn(
                    "flex flex-col items-start gap-2 rounded-xl border border-border/70 bg-background p-4 text-left transition-colors",
                    "hover:border-primary/40 hover:bg-primary/5",
                    "disabled:opacity-60"
                  )}
                >
                  <div className="flex w-full items-center gap-2">
                    <span className="rounded-lg bg-primary/10 p-2 text-primary">
                      <Icon className="h-4 w-4" />
                    </span>
                    <span className="text-sm font-semibold">{account.name}</span>
                  </div>
                  <span className="text-xs font-medium uppercase tracking-wide text-primary/80">
                    {account.role.replace("_", " ")}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {account.description}
                  </span>
                  <span className="mt-1 text-xs text-muted-foreground/80">
                    {busy ? t("auth.signingIn") : t("auth.loginAs")}
                  </span>
                </button>
              );
            })}
          </div>
          {quickError && (
            <p className="mt-3 text-sm text-destructive">{quickError}</p>
          )}
        </section>

        <section className="rounded-2xl border border-border/80 bg-card p-6 shadow-sm">
          <h2 className="text-lg font-semibold">{t("auth.credentialsTitle")}</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {t("auth.credentialsHint")}
          </p>
          <form action={formAction} className="mt-5 flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <label htmlFor="email" className="text-sm font-medium">
                {t("auth.email")}
              </label>
              <Input
                id="email"
                name="email"
                type="email"
                autoComplete="username"
                placeholder="admin@flo.demo"
                required
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label htmlFor="password" className="text-sm font-medium">
                {t("auth.password")}
              </label>
              <Input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                placeholder="demo1234"
                required
              />
            </div>
            {state?.error && (
              <p className="text-sm text-destructive">{state.error}</p>
            )}
            <Button type="submit" disabled={pending} className="w-full">
              {pending ? t("auth.signingIn") : t("auth.signIn")}
            </Button>
          </form>
          <p className="mt-4 text-xs text-muted-foreground">
            {t("auth.passwordNote")}
          </p>
        </section>
      </div>
    </div>
  );
}
