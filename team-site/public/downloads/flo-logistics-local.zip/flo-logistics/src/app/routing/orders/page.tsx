import { prisma } from "@/lib/prisma";
import { OrdersClient } from "@/components/routing/orders-client";
import { getSlaAlertsBundle } from "@/lib/sla-alerts";
import { SlaAlertsPanel } from "@/components/sla-alerts-panel";

export default async function RoutingOrdersPage() {
  const [orders, slaAlerts] = await Promise.all([
    prisma.order.findMany({
      orderBy: { createdAt: "desc" },
    }),
    getSlaAlertsBundle(),
  ]);

  const riskById = new Map(
    slaAlerts.all.map((o) => [o.orderId, o.sla] as const)
  );

  const initialOrders = orders.map((o) => ({
    id: o.id,
    recipientAddress: o.recipientAddress,
    lat: o.lat,
    lng: o.lng,
    accessRequirement: o.accessRequirement,
    status: o.status,
    receivedAt: o.receivedAt ? o.receivedAt.toISOString() : null,
    preparingAt: o.preparingAt ? o.preparingAt.toISOString() : null,
    onRouteAt: o.onRouteAt ? o.onRouteAt.toISOString() : null,
    etaAt: o.etaAt ? o.etaAt.toISOString() : null,
    deliveredAt: o.deliveredAt ? o.deliveredAt.toISOString() : null,
    slaScore: riskById.get(o.id)?.score ?? null,
    slaLevel: riskById.get(o.id)?.level ?? null,
    predictedDelayMin: riskById.get(o.id)?.predictedDelayMin ?? null,
  }));

  return (
    <div className="space-y-6">
      <SlaAlertsPanel data={slaAlerts} />
      <OrdersClient initialOrders={initialOrders} />
    </div>
  );
}
