import { getRoutingLogisticsOverview } from "@/lib/routing-overview";
import { LogisticsReportsClient } from "@/components/routing/logistics-reports-client";
import { buildCarbonAnalytics } from "@/lib/routing/carbon-analytics";
import { CarbonAnalyticsPanel } from "@/components/routing/carbon-analytics-panel";

export default async function LogisticsReportsPage() {
  const overview = await getRoutingLogisticsOverview();
  const carbon = buildCarbonAnalytics(
    overview.report.routes.map((r) => ({
      routePlanId: r.routePlanId,
      driverName: r.driverName,
      vehicleName: r.vehicleName,
      engineType: r.engineType,
      distanceKm: r.distanceKm,
      emissionsKg: r.emissionsKg,
      stops: r.totalStops,
    }))
  );

  return (
    <div className="space-y-6">
      <CarbonAnalyticsPanel data={carbon} />
      <LogisticsReportsClient overview={overview} />
    </div>
  );
}
