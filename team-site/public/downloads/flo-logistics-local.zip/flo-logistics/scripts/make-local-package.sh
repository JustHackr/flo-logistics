#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT_DIR="${ROOT}/team-site/public/downloads"
mkdir -p "$OUT_DIR"
STAMP="$(date +%Y%m%d)"
ZIP="${OUT_DIR}/flo-logistics-local-${STAMP}.zip"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

rsync -a \
  --exclude node_modules \
  --exclude .next \
  --exclude team-site \
  --exclude '**/*.db' \
  --exclude '**/*.db-journal' \
  --exclude .git \
  --exclude deploy \
  --exclude '*.zip' \
  "$ROOT/" "$TMP/flo-logistics/"

(
  cd "$TMP"
  zip -qr "$ZIP" flo-logistics
)

# Keep a stable latest symlink/copy for the Final page
cp "$ZIP" "${OUT_DIR}/flo-logistics-local.zip"
echo "Wrote $ZIP"
echo "Also: ${OUT_DIR}/flo-logistics-local.zip"
