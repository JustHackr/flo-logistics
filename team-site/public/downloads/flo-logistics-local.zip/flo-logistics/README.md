# FLO — Fab Logistics Operations

Next.js logistics prototype for **AI Open Innovation Challenge 2026** (Blibli case): traffic-aware Jakarta last-mile routing, predictive maintenance (VQI), warehouse computer vision, SLA risk scores, and carbon analytics.

**Team site** (journey + presentation): see [`team-site/`](./team-site/).  
**Live VPS target:** `https://radr.nxtdev.xyz/flo-logistics/` (team) · `/flo-logistics/demo/` (this app).

## Quick start (local)

```bash
npm run setup   # install + prisma migrate + seed
npm run dev
```

Open [http://localhost:3000/login](http://localhost:3000/login) and use one-click demo roles (password `demo1234`):

| Email | Role |
|-------|------|
| admin@flo.demo | Admin |
| ops@flo.demo | Ops Manager |
| driver@flo.demo | Driver |
| warehouse@flo.demo | Warehouse |

Or: `npm install && npm run db:migrate && npm run db:seed && npm run dev`.

### Downloadable package

```bash
chmod +x scripts/make-local-package.sh
npm run package:zip
```

Produces `team-site/public/downloads/flo-logistics-local.zip` for the Final page.

## Features for the case brief

- **SLA risk scoring** — traffic, distance, pipeline age, ETA slack → alerts on Home + Orders
- **Delay prediction surface** — predicted delay + hit-rate / MAE on delivered samples
- **Carbon analytics** — per-route / per-shipment CO₂ vs naive baseline on Routing Reports
- **RBAC** — role-scoped menus for judges
- **CV** — load detection + hub congestion (browser); ODOL on roadmap
- **Sovereign-by-design** — self-hostable SQLite stack, swappable LLM, on-device CV

## Routing estimates

| Priority | Source |
|----------|--------|
| 1 (default) | OSRM + Jakarta traffic model |
| 2 (fallback) | Local Jakarta Haversine model |
| 3 (optional) | Google Maps live traffic |

### Optional env

Copy `.env.example`. Useful keys: `FLO_SESSION_SECRET`, `GOOGLE_MAPS_API_KEY`, `AI_API_KEY`, `DATABASE_URL`.

For VPS subpath builds set `NEXT_BASE_PATH=/flo-logistics/demo` (see [`deploy/README.md`](./deploy/README.md)).

## Database

SQLite by default (`file:./dev.db`). Reset:

```bash
npm run db:reset
```

## Team website

```bash
cd team-site
npm install
npm run dev
```

Presentation: `/presentation` (keyboard ← →, Print → PDF).

## Production note

Public OSRM (`router.project-osrm.org`) has no SLA — self-host for scale.
