# Submission drafts — AI Open Innovation Challenge 2026

Deadline: **Sunday, 20 September 2026, 23:59**  
Final pitch: **24 September 2026** (10 menit presentasi + 5 menit Q&A, Bahasa Indonesia)

## 1. Brief overview (≤150 words) — English

FLO (Fab Logistics Operations) helps Blibli run greener, more resilient last-mile logistics. It unifies three AI modules: browser-based computer vision for loading compliance, traffic-aware multi-stop routing with shipment-level carbon analytics, and predictive fleet maintenance without new IoT hardware. Operators get real-time SLA risk scores and delay alerts, plus role-based access for warehouse, drivers, and ops. The stack is sovereign-by-design—self-hostable in Indonesia, aligned with Stranas KA, UU PDP, and UU ITE—so logistics data stays under national control while cutting fuel, emissions, and unplanned downtime.

Word count: ~98

## 2. Ringkasan singkat (≤150 kata) — Bahasa Indonesia

FLO (Fab Logistics Operations) membantu Blibli menjalankan logistik last-mile yang lebih hijau dan tangguh. Tiga modul AI digabungkan: visi komputer di browser untuk kepatuhan muatan, routing sadar lalu lintas dengan analitik karbon per pengiriman, serta pemeliharaan prediktif armada tanpa IoT baru. Operator mendapat skor risiko SLA dan peringatan keterlambatan secara proaktif, plus akses berbasis peran untuk gudang, pengemudi, dan ops. Arsitektur berdaulat—dapat di-host di infrastruktur Indonesia, selaras Stranas KA, UU PDP, dan UU ITE—sehingga data logistik tetap dalam kendali nasional sambil menekan BBM, emisi, dan downtime tak terencana.

## 3. Presentation PDF

1. Buka `https://radr.nxtdev.xyz/flo-logistics/presentation` (atau lokal `team-site` → `/presentation`).
2. Gunakan Print → Save as PDF (satu slide per halaman sudah diatur CSS).
3. Pastikan logo Blibli / FabLab / Kemenko / Pemprov DKI ditambahkan di slide pembuka sebelum submit.
4. Unggah PDF ke Google Drive (aksesible untuk juri) dan kirim tautannya lewat website kompetisi.

## 4. Demo video (opsional alternatif)

Maks. 6 menit, 1080p MP4, tanpa AI voice dubbing. Boleh memakai rekaman live demo + narasi anggota tim.
